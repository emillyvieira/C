#include <stdio.h>

int main() {
	int n, i;
	
	printf("Entre com a quantidade de [Ho]: ");
	scanf("%d", &n);
	
	printf("Ho");
	for (i=1; i<n; i++) printf("-Ho");

	printf(". Feliz Natal!!!");
	
	return 0;
}
